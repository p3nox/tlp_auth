package com.tlp_auth.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.tlp_auth.modelo.Role;
import com.tlp_auth.modelo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tlp_auth.repository.RoleRepository;
import com.tlp_auth.repository.UserRepository;
import com.tlp_auth.modelo.Role;

@Controller
@RequestMapping("/usuario")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
		
	@GetMapping("/novo")
	public String addUser(Model model) {
		model.addAttribute("user", new User());
		return "/public-create-user";
	}
	
	@PostMapping("/salvar")
	public String saveUser(@Valid User user, BindingResult result,
								Model model, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return "/publica-create-user";
		}
		
		User usr = userRepository.findByLogin(user.getLogin());
		if (usr != null) {
			model.addAttribute("loginExist", "Login já esta cadastrado \n");
			return "/publica-create-user";
		}
		
		//Busca o role basico de user
		Role role = roleRepository.findByRole("USER");
		List<Role> roles = new ArrayList<Role>();
		roles.add(role);
		user.setRoles(roles); // associa o role de USER ao usuário
		
		userRepository.save(user);
		attributes.addFlashAttribute("msg", "Usurio salvo com sucesso!");
		return "redirect:/user/new";
	}
	
	@RequestMapping("/admin/list")
	public String listUser(Model model) {
		model.addAttribute("user", userRepository.findAll());
		return "/auth/admin/admin-list-user";
	}
	
	@GetMapping("/admin/delete/{id}")
	public String deleteUser(@PathVariable("id") long id, Model model) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Id invalido:" + id));
		userRepository.delete(user);
	    return "redirect:/user/admin/list";
	}
	
	@GetMapping("/edit/{id}")
	public String editUser(@PathVariable("id") long id, Model model) {
		Optional<User> userOld = userRepository.findById(id);
		if (!userOld.isPresent()) {
            throw new IllegalArgumentException("Usuário inválido:" + id);
        } 
		User user = userOld.get();
	    model.addAttribute("user", user);
	    return "/auth/user/user-edit-user";
	}
	
	@PostMapping("/edit/{id}")
	public String editUser(@PathVariable("id") long id,
								@Valid User user, BindingResult result) {
		if (result.hasErrors()) {
	    	user.setId(id);
	        return "/auth/user/user-alt-user";
	    }
	    userRepository.save(user);
	    return "redirect:/user/admin/list";
	}
		
	@GetMapping("/editRole/{id}")
	public String selectRole(@PathVariable("id") long id, Model model) {
		Optional<User> userOld = userRepository.findById(id);
		if (!userOld.isPresent()) {
            throw new IllegalArgumentException("Usuário invalido:" + id);
        } 
		User user = userOld.get();
	    model.addAttribute("user", user);
	    
	    model.addAttribute("listRoles", roleRepository.findAll());
	    
	    return "/auth/admin/admin-edit-role-user";
	}
	
	@PostMapping("/editRole/{id}")
	public String assignRole(@PathVariable("id") long idUser,
								@RequestParam(value = "pps", required=false) int[] pps, 
								User user,
								RedirectAttributes attributes) {
		if (pps == null) {
			user.setId(idUser);
			attributes.addFlashAttribute("msg", "Pelo menos um papel deve ser informado");
			return "redirect:/user/editRoles/"+idUser;
		} else {
			//Obtém a lista de papéis selecionada pelo usuário do banco
			List<Role> roles = new ArrayList<Role>();
			for (int i = 0; i < pps.length; i++) {
				long idRole = pps[i];
				Optional<Role> roleOptional = roleRepository.findById(idRole);
				if (roleOptional.isPresent()) {
					Role role = roleOptional.get();
					roles.add(role);
		        }
			}
			Optional<User> userOptional = userRepository.findById(idUser);
			if (userOptional.isPresent()) {
				User usr = userOptional.get();
				usr.setRoles(roles); // relaciona papéis ao usuário
				usr.setActive(user.isActive());
				userRepository.save(usr);
	        }			
		}		
	    return "redirect:/user/admin/list";
	}
}
