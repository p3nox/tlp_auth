package com.tlp_auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tlp_authApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tlp_authApplication.class, args);
	}

}
