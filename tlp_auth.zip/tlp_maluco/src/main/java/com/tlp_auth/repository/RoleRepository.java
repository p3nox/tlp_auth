package com.tlp_auth.repository;

import com.tlp_auth.modelo.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
	Role findByRole(String role);
}
