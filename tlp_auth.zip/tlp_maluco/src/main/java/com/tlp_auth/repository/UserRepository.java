package com.tlp_auth.repository;

import com.tlp_auth.modelo.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
	User findByLogin(String login);
}
